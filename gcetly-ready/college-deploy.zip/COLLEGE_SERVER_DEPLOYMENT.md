﻿# GCE-TLY AI Assistant — Permanent College Server Deployment Guide

> **Version:** 3.8 | **Last Updated:** August 2026
> **Cost:** Rs. 0 ongoing — runs 100% locally on college hardware.

---

## 1. System Architecture

`
[ Students / Faculty / Visitors ]
           |
           v
  [ NGINX Reverse Proxy ]  (Optional: SSL & custom domain ai.gcetly.ac.in)
           |
           v
  [ Next.js Production Server — Port 3000 ]
       |-- BM25 RAG Retriever  (data/gcetly-faqs.json)
       |-- SQLite Database     (data/gcetly.db)
       |-- Answer Cache        (instant repeat answers)
       +-- Ollama LLM Driver
           |
           v
  [ Ollama Engine — Port 11434 ]
    +-- Model: qwen2.5:3b  (kept in RAM 24/7)
`

---

## 2. Server Requirements

| Component | Minimum | Recommended |
|---|---|---|
| OS | Windows 10/11 or Ubuntu 22.04 | Windows Server 2022 / Ubuntu 24.04 LTS |
| RAM | 8 GB | 16 GB |
| CPU | 4 Cores | 8 Cores |
| GPU | None (CPU works) | NVIDIA 4 GB+ VRAM (CUDA) |
| Storage | 10 GB SSD | 20 GB SSD |
| Node.js | v20 LTS | v22 LTS |

> GPU Note: CUDA reduces response time from ~10s to ~1s.

---

## 3. One-Time Setup (Windows)

### Step 1 — Install Node.js
- Download from: https://nodejs.org (LTS version)
- Verify: 
ode --version

### Step 2 — Install Ollama and Download Model
`
https://ollama.com
ollama pull qwen2.5:3b
`
(Downloads ~2 GB once. No internet needed after.)

### Step 3 — Install Dependencies and Build
`powershell
cd C:\ai\gcetly-ready
npm install
npm run build
`

### Step 4 — Start Server
Double-click: C:\ai\gcetly-ready\start-server.bat

Server runs at: http://localhost:3000

---

## 4. Auto-Start on Reboot (Windows)

### Option A: PM2 (Recommended)

`powershell
npm install -g pm2
npm install -g pm2-windows-startup
pm2-startup install

cd C:\ai\gcetly-ready
pm2 start "node_modules\.bin\next" --name "gcetly-chatbot" -- start -p 3000 -H 0.0.0.0
pm2 save
`

Useful commands:
`powershell
pm2 status
pm2 logs gcetly-chatbot
pm2 restart gcetly-chatbot
`

### Option B: Windows Task Scheduler

1. Open: taskschd.msc
2. Create Task:
   - General: "Run whether user is logged on or not" + "Run with highest privileges"
   - Triggers: At startup
   - Actions: Program = C:\ai\gcetly-ready\start-server.bat

---

## 5. Auto-Start on Reboot (Linux / Ubuntu)

`ash
sudo nano /etc/systemd/system/gcetly-chatbot.service
`

Paste:
`ini
[Unit]
Description=GCE-TLY AI Assistant
After=network.target

[Service]
Type=simple
User=www-data
WorkingDirectory=/var/www/gcetly-ready
ExecStart=/usr/bin/npm run start -- -p 3000 -H 0.0.0.0
Restart=always
RestartSec=5
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
`

Enable:
`ash
sudo systemctl daemon-reload
sudo systemctl enable gcetly-chatbot
sudo systemctl start gcetly-chatbot
`

---

## 6. Campus LAN Access

Open Windows Firewall:
`powershell
New-NetFirewallRule -DisplayName "GCE-TLY Chatbot" -Direction Inbound -LocalPort 3000 -Protocol TCP -Action Allow
`

Access from any device on campus:
`
http://<SERVER-LAN-IP>:3000
`

Find your IP: ipconfig | Select-String "IPv4"

---

## 7. Custom Domain + SSL (ai.gcetly.ac.in)

`ash
sudo apt install nginx certbot python3-certbot-nginx

sudo nano /etc/nginx/sites-available/gcetly
`

NGINX config:
`
ginx
server {
    server_name ai.gcetly.ac.in;
    location / {
        proxy_pass         http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header   Host System.Management.Automation.Internal.Host.InternalHost;
        proxy_set_header   X-Real-IP ;
        proxy_buffering    off;
        proxy_read_timeout 180s;
    }
}
`

Enable + get free SSL:
`ash
sudo ln -s /etc/nginx/sites-available/gcetly /etc/nginx/sites-enabled/
sudo systemctl reload nginx
sudo certbot --nginx -d ai.gcetly.ac.in
`

---

## 8. Environment Configuration (.env.local)

`env
# AI Engine
LLM_PROVIDER=ollama
OLLAMA_HOST=http://localhost:11434
OLLAMA_MODEL=qwen2.5:3b

# Keep model in RAM permanently (zero cold-start)
OLLAMA_KEEP_ALIVE=-1
OLLAMA_TIMEOUT_MS=120000
OLLAMA_NUM_CTX=1536
OLLAMA_NUM_PREDICT=160
OLLAMA_NUM_THREAD=4

# Speed features
FREE_MODE=1
FAQ_FAST_PATH=1
VECTOR_RETRIEVAL=0

# Admin password — CHANGE THIS before public deployment!
ADMIN_ACCESS_TOKEN=gcetly-admin-2026
`

---

## 9. Admin Panel — Adding New Documents

URL: http://localhost:3000/admin
Password: value of ADMIN_ACCESS_TOKEN in .env.local

Steps to add new PDF circulars/notices:
1. Open Admin -> Documents tab
2. Enter a title (e.g. "Admission 2026-27 Circular")
3. Upload PDF or text file
4. Review extracted chunks
5. Click "Approve & Index" — chatbot learns it instantly, no restart needed!

---

## 10. Health Check

`
GET http://localhost:3000/api/health
`

Returns: Ollama status, model in RAM, knowledge count, SQLite status.

---

## 11. Troubleshooting

| Problem | Fix |
|---|---|
| "This operation was aborted" | Ollama is cold. Run: ollama run qwen2.5:3b "ping" to warm up. |
| "Can't reach Ollama" | Run "ollama serve" in a terminal. Use start-server.bat. |
| Port 3000 not on LAN | Add Windows Firewall rule (Section 6). |
| Server stops after reboot | Use PM2 (Section 4). |
| Slow responses (>15s) | Set OLLAMA_NUM_THREAD to CPU core count; use NVIDIA GPU + CUDA. |
| Build fails | Run: npx tsc --noEmit first to see errors. |
| Admin access denied | Check ADMIN_ACCESS_TOKEN in .env.local matches password typed. |

---

## 12. Quick Reference

`powershell
npm run build                          # Build for production
node_modules\.bin\next start -p 3000  # Start production server
npm test                               # Run all 135 tests
npx tsc --noEmit                       # TypeScript type-check only
ollama run qwen2.5:3b "ping"          # Warm up AI model
curl http://localhost:3000/api/health  # Check health
`

---

GCE-TLY AI Assistant — Government College of Engineering, Tirunelveli
Runs fully offline — zero cloud cost, complete data privacy.
